-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2019 at 07:39 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `latest1`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(4) NOT NULL,
  `title` varchar(225) NOT NULL,
  `author` varchar(225) NOT NULL,
  `postdate` date NOT NULL,
  `image` text NOT NULL,
  `content` text NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(225) NOT NULL,
  `tag` varchar(300) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `author`, `postdate`, `image`, `content`, `updated_on`, `status`, `tag`, `category`) VALUES
(1, 'Group Revenue Management', 'admin', '2019-06-26', '30389.png', 'GroupRM is an innovative solution that helps airlines to effectively control group traffic. It aids in increasing sales by enabling the group analysts to better manage and optimize group sales. Group requestor interface&nbsp;provides a customizable ad- hoc or series group request form for the different types of requesters like direct customers, travel agents, corporate travel managers, airline sales force and group desk analyst. Group processing interface&nbsp;&nbsp;provides the analyst in the airline group desk to monitor incoming group request, evaluate them, provide fare quotes and respond back to the customers. Group ticketing&nbsp;&nbsp;module interfaces with the airline reservation system to create a group PNR and subsequently insert names along with the terms and conditions. The requestor can directly enter the names and details for group booking.', '2019-06-26 15:10:56', 'published', 'Airline,GroupRM', 'Travel'),
(2, 'Business Travel Management Solution', 'admin', '2019-06-26', '257487.png', 'AtYourPrice is a robust web based business travel solution that automates travel planning, requisition, approval, fulfillment, invoicing, reporting and duty of care. Automation brings exponential savings to business travel programs and also makes the travel procurement process more operationally efficient. Customised work flow&nbsp;is automate and alert your travel or trip approver with not just necessity to travel but also cost associated with it. With our multi level work flow engine travelers and approvers will be able to effectively and efficiently plan and approve travel requests or indents.', '2019-06-26 15:12:35', 'published', 'packages,business travel', 'Travel'),
(3, 'Airline Forecasting Tool', 'admin', '2019-06-26', '746744.png', 'CrAFT is an intuitive and highly effective revenue management solution based on accurate forecasting for airlines, devised by our experts who have decades of experience with designing successful revenue management systems and processes for several international airlines. CrAFT is also having various versions designed to suit airlines with different scales of operations and business models.', '2019-06-26 14:56:07', 'published', 'airline,packages,deals', 'Product'),
(4, 'Bitcoin Technology', 'admin', '2019-06-26', '947380.jpg', 'Bitcoin&nbsp;(â‚¿) is a&nbsp;cryptocurrency, a form of electronic cash. It is a decentralized&nbsp;digital currency&nbsp;without a&nbsp;central bank&nbsp;or single administrator that can be sent from user to user on the&nbsp;peer-to-peer&nbsp;bitcoin network without the need for intermediaries.\r\nTransactions are verified by network&nbsp;nodes&nbsp;through&nbsp;cryptography&nbsp;and recorded in a public&nbsp;distributed ledger&nbsp;called a&nbsp;blockchain. Bitcoin was invented by an unknown person or group of people using the name&nbsp;Satoshi Nakamoto&nbsp;and was released as&nbsp;open-source software&nbsp;in 2009.Bitcoins are created as a reward for a process known as&nbsp;mining. They can be exchanged for other currencies, products, and services.&nbsp;Research produced by&nbsp;University of Cambridge&nbsp;estimates that in 2017, there were 2.9 to 5.8 million unique users using a&nbsp;cryptocurrency wallet, most of them using bitcoin.', '2019-06-26 15:08:32', 'published', 'bitcoin,deals,holidays', 'Technology'),
(5, 'Explore Bharat Hubs', 'admin', '2019-06-26', '854242.jpg', 'Today, 10 prominent Indian states account for more than 75per cent of India&rsquo;s aggregate GDP including Rajasthan, Madhya Pradesh, and Uttar Pradesh, and tier II cities such as Surat, Jaipur, Indore, and Patna have shown an economic growth rate of more than 40%.This paradigm shift in the tier II and III cities is quite evident in the current economic scenario where an extensive number of startups are emerging with the motive of solving more localized problems with the help of on-demand applications, consumer tech solutions, online delivery, ride sharing and more, thereby driving the growth of IT in these cities.&nbsp;', '2019-06-26 17:10:07', 'published', 'explore,packages,airline', 'Events'),
(6, 'Encode36 Hackathon', 'admin', '2019-06-26', '666411.jpg', 'It&#39;s not about ideas, it&#39;s about making ideas happen.\r\nAt the heart of Infiniti is Innovation. We constantly upgrade our offerings to deliver the best service to our customers. Thinking on these lines, today and tomorrow we are having 36 hours of non-stop code day.13 teams are participating in our Chennai Infiniti Campus to bring ideas to life with AI.\r\nWe are all charged up with what&#39;s next for travel technology as we begin the first day of&nbsp;#EnCode-36.', '2019-06-26 17:37:10', 'published', 'deals,hackathon,packages', 'Achievements');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(4) NOT NULL,
  `username` varchar(225) NOT NULL,
  `firstname` varchar(225) NOT NULL,
  `lastname` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `role` varchar(225) NOT NULL DEFAULT 'user'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstname`, `lastname`, `email`, `password`, `role`) VALUES
(1, 'admin123', 'admin', 'admin', 'admin@gmail.com', '$2y$10$GdfeamNAb8AxvyFD.wnc5.8Ik7m7jHfuLuZ.jvMo85IVfKG8tCKnm', 'admin'),
(2, 'sugu', 'suganya', 'divv', 'suganyadivv@gmail.com', '$2y$10$AfZdAXVWDK8BUH3u7qC5j.rtVtGTiv4fJ6B8DuN9yo63.nlQxy6Om', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
