



<div class="well">
                    <h4 class="text-primary text-center"><b>SIGN-UP</b></h4>
                    <form method="POST" action="login.php">
                    <div class="">
                         <input name="user_name" type="text" class="form-control" placeholder="Enter Username" required>
                    </div>
                    <br>
                    <div class="">
                        <input name="user_password" type="password" class="form-control" placeholder="Enter Passsword" required>
						</div>
                        <br>
                        <span class="input-group-btn">
                            
                           <center> <button name="login" class="btn btn-primary" type="submit">Submit</button></center>
                  </span>
                    </div>
                    </form>
                    <hr><img src="http://spiceroutemagazine.com/wp-content/uploads/2017/05/1-SR-MAY-2017-COVER-.jpg" width="300px" height="500px">
                    
</div>


