  <nav class="navbar navbar-default navbar-fixed-top" role="navigation"" style="background-color:#ffffff;border-color:#333;">
			<div class="container-fluid">


				<div class="navbar-header">
					 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle Navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.php"><img src="infiniti-logo.png" width="150px" alt="INFINITI" class="img-responsive"></a>
				</div>

				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				
				    <ul class="nav navbar-nav navbar-right">
                    	<li><a href="about.php"><b>About Us</b></a></li>
					  <li><a href="register.php"><b>Sign-in</b></a></li>
				
						  </ul>
	
	  <form method="POST" action="search.php" class="navbar-form navbar-right">
                    <div class="input-group">
                        <input name="search" type="text" class="form-control" placeholder="Search" required>
                        <span class="input-group-btn">
                            <button name="submit" class="btn btn-default" type="submit">
                                <span class="glyphicon glyphicon-search"></span>
                        </button>
                        </span>
                    </div>
                    </form>
				</div>
			</div>
	    </nav>
		
