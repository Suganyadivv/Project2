<?php
$conn = mysqli_connect("localhost","root","","latest1" ) or die ("error" . mysqli_error($conn));
?>